# FixChat — Flutter MVP Scaffold

**Fast Intelligent eXecution with AI**
*Ask. Allow. Done.*

এই ZIP-এ শুধু `lib/`, `pubspec.yaml`, `.gitignore` আছে — অর্থাৎ Dart কোড ও কনফিগ। প্ল্যাটফর্ম ফোল্ডার (`android/`, `ios/`) নেই, কারণ সেগুলো Flutter CLI দিয়ে জেনারেট করতে হয় (আমার sandbox-এ ইন্টারনেট/Flutter SDK নেই)।

## সেটআপ (তোমার কম্পিউটারে)

1. Flutter SDK ইনস্টল করা থাকতে হবে (না থাকলে: https://docs.flutter.dev/get-started/install)
2. একটা খালি ফোল্ডারে গিয়ে:
   ```bash
   flutter create fixai
   ```
   এতে `android/`, `ios/` সহ পুরো বেস প্রজেক্ট তৈরি হবে।
3. এই ZIP-এর `lib/`, `pubspec.yaml`, `.gitignore` কপি করে নতুন `fixai/` ফোল্ডারের ভেতরে **replace** করে দাও (পুরনো `lib/` আর `pubspec.yaml` ওভাররাইট হবে)।
4. ডিপেন্ডেন্সি ইনস্টল করো:
   ```bash
   cd fixai
   flutter pub get
   ```
5. রান করো:
   ```bash
   flutter run
   ```

## GitHub-এ আপলোড ও APK বিল্ড (Orthi-র মতো)

⚠️ **গুরুত্বপূর্ণ:** এই ZIP-এ `.github/workflows/build-apk.yml` আছে, কিন্তু সেটা কাজ করার জন্য `android/` ফোল্ডার লাগবে — যেটা এই ZIP-এ নেই (উপরের সেটআপ ধাপ দেখো)।

**সঠিক ধাপ:**
1. উপরের "সেটআপ" অংশ অনুযায়ী `flutter create fixchat` চালাও, তারপর এই ZIP-এর ফাইলগুলো (lib/, pubspec.yaml, .github/, README.md, .gitignore) সেই ফোল্ডারে বসাও।
2. এতে `android/`, `ios/` ফোল্ডারও তৈরি হয়ে যাবে — এগুলোও GitHub-এ পুশ করতে হবে (এগুলো `.gitignore`-এ বাদ দেওয়া নেই, শুধু `local.properties` বাদ)।
3. GitHub-এ নতুন রিপো বানাও (যেমন `fixchat`), তারপর পুরো `fixchat/` ফোল্ডার পুশ করো:
   ```bash
   cd fixchat
   git init
   git add .
   git commit -m "Initial FixChat setup"
   git branch -M main
   git remote add origin https://github.com/<তোমার-ইউজারনেম>/fixchat.git
   git push -u origin main
   ```
4. পুশ করার সাথে সাথে GitHub Actions (`build-apk.yml`) অটোমেটিক চলবে এবং APK বিল্ড হবে। রিপোর **Actions** ট্যাবে গিয়ে বিল্ড শেষ হলে **Artifacts** থেকে `fixchat-release-apk` ডাউনলোড করতে পারবে।

**যদি শুধু কোড রিভিউ/শেয়ার করার জন্য GitHub-এ দিতে চাও** (এখনই বিল্ড না করেও), তাহলে `android/`, `ios/` ছাড়াই এই ZIP সরাসরি পুশ করে দিলেও চলবে — শুধু Actions workflow তখন fail করবে যতক্ষণ না `flutter create .` চালানো ফোল্ডারটা পুশ করছো।

## এখন যা আছে (UI Shell — কোনো Real AI/Backend নেই)

- **Home** — Quick actions (AI Chat, Voice, Screenshot, Scan Device) + Recent Problems + Popular Fixes
- **AI Chat** — Text input, simulated AI response, "Fix Automatically" বাটন, execution progress bar (Stop/Pause/Take Control)
- **Scan Device** — ব্লুপ্রিন্টের ১২টা ক্যাটাগরি স্ক্যান UI (simulated result)
- **History** — সমস্যার তালিকা
- **Profile** — নাম/ইমেইল/Plan status + Settings লিস্ট

সবকিছু **dummy/simulated data** দিয়ে কাজ করছে — কোনো real backend, AI API, বা device permission call নেই এখনো। কোডে যেখানে যেখানে পরের ধাপে real logic বসবে, সেখানে `// TODO:` কমেন্ট রাখা আছে।

## 🔄 Auto-Update System (নতুন!)

এখন থেকে প্রতিবার নতুন কোড আপডেট করলে তোমাকে নতুন ZIP ইনস্টল করতে হবে না — অ্যাপ নিজেই GitHub Release চেক করে নতুন ভার্সন থাকলে ডাউনলোড+ইনস্টল করার অপশন দেখাবে।

### সেটআপ করতে যা করতে হবে (একবারই):

1. **`lib/services/update_service.dart`** ফাইলে গিয়ে এই দুইটা লাইন বদলাও:
   ```dart
   static const String owner = 'YOUR_GITHUB_USERNAME'; // তোমার GitHub username
   static const String repo = 'fixchat';                // রিপোর নাম
   ```

2. **Android permission যোগ করো** — `flutter create .` চালানোর পর `android/app/src/main/AndroidManifest.xml` ফাইলে `<application>` ট্যাগের **ভিতরে** এই লাইন যোগ করো:
   ```xml
   <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
   ```
   (এই permission ছাড়া APK ইনস্টলার খুলবে না)

### প্রতিবার নতুন আপডেট দেওয়ার নিয়ম:

1. কোড আপডেট করো, `pubspec.yaml`-এ `version:` নম্বরটা বাড়াও (যেমন `1.0.0+1` → `1.0.1+2`)
2. GitHub-এ পুশ করো, তারপর একটা ভার্সন ট্যাগ দাও:
   ```bash
   git add .
   git commit -m "নতুন ফিচার যোগ"
   git push
   git tag v1.0.1
   git push origin v1.0.1
   ```
3. এই ট্যাগ পুশ করার সাথে সাথে `.github/workflows/release.yml` অটোমেটিক চলবে, APK বিল্ড করবে, এবং একটা GitHub Release-এ APK অ্যাটাচ করবে।
4. ফোনে যাদের কাছে অ্যাপ ইনস্টল করা আছে, তারা অ্যাপ খুললেই "নতুন আপডেট" ডায়ালগ দেখবে — এক ট্যাপে ইনস্টল হয়ে যাবে।

> ⚠️ প্রথমবার অ্যাপ ইনস্টল করার জন্য এখনো manual APK লাগবে (`build-apk.yml`-এর Artifacts থেকে, বা প্রথম `v1.0.0` release থেকে) — auto-updater শুধু পরের আপডেটগুলোর জন্য কাজ করে।

## পরের সম্ভাব্য ধাপ

- [ ] Gemini/OpenAI API ইন্টিগ্রেশন (real AI Chat)
- [ ] `speech_to_text` প্যাকেজ দিয়ে Voice input
- [ ] `image_picker` দিয়ে Screenshot analysis
- [ ] Real device scan (battery, storage, RAM ইত্যাদির জন্য platform-specific প্যাকেজ লাগবে)
- [ ] Firebase/Supabase auth + backend
- [ ] Dark mode toggle বাস্তবায়ন
